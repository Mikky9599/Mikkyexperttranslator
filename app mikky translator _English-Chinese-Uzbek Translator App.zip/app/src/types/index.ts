export type Language = 'en' | 'zh' | 'uz';

export interface Translation {
  en: string;
  zh: string;
  uz: string;
  enPronunciation?: string;
  zhPronunciation?: string;
  uzPronunciation?: string;
}

export interface WordEntry {
  id: string;
  category: Category;
  translations: Translation;
  example: Translation;
  difficulty: 'easy' | 'medium' | 'hard';
  tags: string[];
}

export type Category = 
  | 'greetings' 
  | 'food' 
  | 'travel' 
  | 'shopping' 
  | 'health' 
  | 'work' 
  | 'family' 
  | 'numbers' 
  | 'time' 
  | 'weather' 
  | 'emotions' 
  | 'colors'
  | 'education'
  | 'directions' 
  | 'transportation' 
  | 'accommodation' 
  | 'restaurant' 
  | 'emergency' 
  | 'conversation';

export interface CategoryInfo {
  id: Category;
  name: Translation;
  icon: string;
  color: string;
}

export interface FavoriteList {
  id: string;
  name: string;
  entries: string[];
  createdAt: number;
}

export interface QuizQuestion {
  id: string;
  question: Translation;
  correctAnswer: string;
  options: string[];
  category: Category;
}

export interface UserSettings {
  baseLanguage: Language;
  dailyReminder: boolean;
  reminderTime: string;
  offlineMode: boolean;
}

export interface UsefulWord {
  en: string;
  zh: string;
  uz: string;
}

export interface ConversationScenario {
  id: string;
  title: Translation;
  description: Translation;
  introduction: Translation;
  usefulWords: UsefulWord[];
  dialogues: Dialogue[];
  category: Category;
}

export interface Dialogue {
  id: string;
  speaker: string;
  text: Translation;
  audioUrl?: string;
}
