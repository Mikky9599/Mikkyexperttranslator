import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { Toaster } from 'sonner'
import './index.css'
import App from './App.tsx'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
    <Toaster 
      position="top-center"
      toastOptions={{
        style: {
          background: '#FDF6E3',
          border: '3px solid rgba(26, 26, 46, 0.85)',
          borderRadius: '18px',
          boxShadow: '0 6px 0 rgba(26, 26, 46, 0.85)',
          fontFamily: 'Nunito, sans-serif',
          fontWeight: 700,
        },
      }}
    />
  </StrictMode>,
)
