import type { ConversationScenario } from '@/types';

// Helper to add pinyin to Chinese text
const zh = (text: string, pinyin: string) => `${text} (${pinyin})`;

export const conversationScenarios: ConversationScenario[] = [
  {
    id: 'sc_001',
    title: {
      en: 'About Myself',
      zh: zh('关于我自己', 'Guānyú wǒ zìjǐ'),
      uz: 'O\'zim haqida'
    },
    description: {
      en: 'Introducing yourself to someone new',
      zh: zh('向新朋友介绍自己', 'Xiàng xīn péngyǒu jièshào zìjǐ'),
      uz: 'Yangi tanishga o\'zingizni tanishtirish'
    },
    category: 'conversation',
    introduction: {
      en: 'Use these phrases when meeting someone for the first time.',
      zh: zh('第一次见某人时使用这些短语。', 'Dì yī cì jiàn mǒu rén shí shǐyòng zhèxiē duǎnyǔ.'),
      uz: 'Biror kishini birinchi marta uchraganingizda ushbu iboralardan foydalaning.'
    },
    usefulWords: [
      { en: 'name', zh: zh('名字', 'míngzi'), uz: 'ism' },
      { en: 'age', zh: zh('年龄', 'niánlíng'), uz: 'yosh' },
      { en: 'from', zh: zh('来自', 'láizì'), uz: 'dan' },
      { en: 'live', zh: zh('住', 'zhù'), uz: 'yashamoq' },
      { en: 'work', zh: zh('工作', 'gōngzuò'), uz: 'ish' },
      { en: 'student', zh: zh('学生', 'xuésheng'), uz: 'talaba' },
      { en: 'country', zh: zh('国家', 'guójiā'), uz: 'davlat' },
      { en: 'language', zh: zh('语言', 'yǔyán'), uz: 'til' }
    ],
    dialogues: [
      {
        id: 'dlg_001',
        speaker: 'A',
        text: {
          en: 'Hello! My name is David. What is your name?',
          zh: zh('你好！我叫大卫。你叫什么名字？', 'Nǐ hǎo! Wǒ jiào Dàwèi. Nǐ jiào shénme míngzì?'),
          uz: 'Salom! Mening ismim David. Sizning ismingiz nima?'
        }
      },
      {
        id: 'dlg_002',
        speaker: 'B',
        text: {
          en: 'Hi David! I am Maria. Nice to meet you.',
          zh: zh('嗨大卫！我是玛丽亚。很高兴认识你。', 'Hāi Dàwèi! Wǒ shì Mǎlìyà. Hěn gāoxìng rènshi nǐ.'),
          uz: 'Salom David! Men Maria. Tanishganimdan xursandman.'
        }
      },
      {
        id: 'dlg_003',
        speaker: 'A',
        text: {
          en: 'Nice to meet you too. Where are you from?',
          zh: zh('我也很高兴认识你。你来自哪里？', 'Wǒ yě hěn gāoxìng rènshi nǐ. Nǐ láizì nǎlǐ?'),
          uz: 'Men ham tanishganimdan xursandman. Siz qayerdansiz?'
        }
      },
      {
        id: 'dlg_004',
        speaker: 'B',
        text: {
          en: 'I am from China. I live in Beijing. How about you?',
          zh: zh('我来自中国。我住在北京。你呢？', 'Wǒ láizì Zhōngguó. Wǒ zhù zài Běijīng. Nǐ ne?'),
          uz: 'Men Xitoydanman. Men Pekinda yashayman. Sizchi?'
        }
      },
      {
        id: 'dlg_005',
        speaker: 'A',
        text: {
          en: 'I am from Uzbekistan. I live in Tashkent.',
          zh: zh('我来自乌兹别克斯坦。我住在塔什干。', 'Wǒ láizì Wūzībiékèsītǎn. Wǒ zhù zài Tǎshígān.'),
          uz: 'Men O\'zbekistondanman. Men Toshkentda yashayman.'
        }
      },
      {
        id: 'dlg_006',
        speaker: 'B',
        text: {
          en: 'What do you do? Are you a student?',
          zh: zh('你是做什么的？你是学生吗？', 'Nǐ shì zuò shénme de? Nǐ shì xuésheng ma?'),
          uz: 'Siz nima ish qilasiz? Talabamisiz?'
        }
      },
      {
        id: 'dlg_007',
        speaker: 'A',
        text: {
          en: 'Yes, I am a student. I study English and Chinese.',
          zh: zh('是的，我是学生。我学英语和中文。', 'Shì de, wǒ shì xuésheng. Wǒ xué Yīngyǔ hé Zhōngwén.'),
          uz: 'Ha, men talabaman. Men ingliz va xitoy tilini o\'qiyman.'
        }
      },
      {
        id: 'dlg_008',
        speaker: 'B',
        text: {
          en: 'That is wonderful! How long have you been studying Chinese?',
          zh: zh('太棒了！你学中文多久了？', 'Tài bàng le! Nǐ xué Zhōngwén duōjiǔ le?'),
          uz: 'Bu ajoyib! Siz xitoy tilini qancha vaqt o\'qiyotgan bo\'ldingiz?'
        }
      },
      {
        id: 'dlg_009',
        speaker: 'A',
        text: {
          en: 'For about two years. It is difficult but very interesting.',
          zh: zh('大约两年了。很难但很有趣。', 'Dàyuē liǎng nián le. Hěn nán dàn hěn yǒuqù.'),
          uz: 'Taqriban ikki yil. Bu qiyin lekin juda qiziqarli.'
        }
      },
      {
        id: 'dlg_010',
        speaker: 'B',
        text: {
          en: 'Keep practicing! Your Chinese is already very good.',
          zh: zh('继续练习！你的中文已经很好了。', 'Jìxù liànxí! Nǐ de Zhōngwén yǐjīng hěn hǎo le.'),
          uz: 'Mashq qilishda davom eting! Sizning xitoychingiz allaqachon juda yaxshi.'
        }
      }
    ]
  },
  {
    id: 'sc_002',
    title: {
      en: 'At the Restaurant',
      zh: zh('在餐厅', 'Zài cāntīng'),
      uz: 'Restoranda'
    },
    description: {
      en: 'Ordering food and drinks',
      zh: zh('点餐和饮料', 'Diǎn cān hé yǐnliào'),
      uz: 'Ovqat va ichimlik buyurtma qilish'
    },
    category: 'restaurant',
    introduction: {
      en: 'Useful phrases for dining at a restaurant.',
      zh: zh('在餐厅用餐时的有用短语。', 'Zài cāntīng yòngcān shí de yǒuyòng duǎnyǔ.'),
      uz: 'Restoranda ovqatlanish uchun foydali iboralar.'
    },
    usefulWords: [
      { en: 'menu', zh: zh('菜单', 'càidān'), uz: 'menyu' },
      { en: 'order', zh: zh('点菜', 'diǎncài'), uz: 'buyurtma' },
      { en: 'water', zh: zh('水', 'shuǐ'), uz: 'suv' },
      { en: 'bill', zh: zh('账单', 'zhàngdān'), uz: 'hisob' },
      { en: 'delicious', zh: zh('好吃', 'hǎochī'), uz: 'mazali' },
      { en: 'spicy', zh: zh('辣', 'là'), uz: 'achchiq' },
      { en: 'recommend', zh: zh('推荐', 'tuījiàn'), uz: 'tavsiya qilish' },
      { en: 'vegetarian', zh: zh('素食', 'sùshí'), uz: 'vegetarian' }
    ],
    dialogues: [
      {
        id: 'dlg_011',
        speaker: 'Waiter',
        text: {
          en: 'Good evening! Welcome to our restaurant. A table for how many?',
          zh: zh('晚上好！欢迎光临我们餐厅。几位？', 'Wǎnshang hǎo! Huānyíng guānglín wǒmen cāntīng. Jǐ wèi?'),
          uz: 'Xayrli kech! Restoranimizga xush kelibsiz. Necha kishi?'
        }
      },
      {
        id: 'dlg_012',
        speaker: 'Customer',
        text: {
          en: 'Table for two, please. Near the window if possible.',
          zh: zh('请给两人桌。如果可能的话靠窗的。', 'Qǐng gěi liǎng rén zhuō. Rúguǒ kěnéng de huà kào chuāng de.'),
          uz: 'Iltimos, ikki kishilik stol. Mumkin bo\'lsa, deraza yonida.'
        }
      },
      {
        id: 'dlg_013',
        speaker: 'Waiter',
        text: {
          en: 'Right this way. Here is the menu. What would you like to drink?',
          zh: zh('请这边走。这是菜单。您想喝点什么？', 'Qǐng zhè biān zǒu. Zhè shì càidān. Nín xiǎng hē diǎn shénme?'),
          uz: 'Mana bu yo\'l. Mana menyu. Nima ichmoqchisiz?'
        }
      },
      {
        id: 'dlg_014',
        speaker: 'Customer',
        text: {
          en: 'I would like water, please. And what do you recommend for today?',
          zh: zh('请给我水。今天你有什么推荐的？', 'Qǐng gěi wǒ shuǐ. Jīntiān nǐ yǒu shénme tuījiàn de?'),
          uz: 'Iltimos, suv. Va bugun nima tavsiya qilasiz?'
        }
      },
      {
        id: 'dlg_015',
        speaker: 'Waiter',
        text: {
          en: 'Today\'s special is grilled fish. It is very delicious and fresh.',
          zh: zh('今天的特色菜是烤鱼。非常好吃又新鲜。', 'Jīntiān de tèsè cài shì kǎo yú. Fēicháng hǎochī yòu xīnxiān.'),
          uz: 'Bugungi maxsus taom - qovurilgan baliq. Juda mazali va yangi.'
        }
      },
      {
        id: 'dlg_016',
        speaker: 'Customer',
        text: {
          en: 'That sounds good. I will have that. Is it very spicy?',
          zh: zh('听起来不错。我要那个。很辣吗？', 'Tīng qǐlái búcuò. Wǒ yào nàge. Hěn là ma?'),
          uz: 'Yaxshi eshitiladi. Men shuni olaman. U juda achchiqmi?'
        }
      },
      {
        id: 'dlg_017',
        speaker: 'Waiter',
        text: {
          en: 'It is mildly spicy. I can make it less spicy if you prefer.',
          zh: zh('有点辣。如果您喜欢，我可以做得不那么辣。', 'Yǒudiǎn là. Rúguǒ nín xǐhuān, wǒ kěyǐ zuò de bù nàme là.'),
          uz: 'U biroz achchiq. Agar xohlasangiz, men uni kamroq achchiq qilishim mumkin.'
        }
      },
      {
        id: 'dlg_018',
        speaker: 'Customer',
        text: {
          en: 'Yes, please make it less spicy. Thank you.',
          zh: zh('好的，请做得不那么辣。谢谢。', 'Hǎo de, qǐng zuò de bù nàme là. Xièxiè.'),
          uz: 'Ha, iltimos, uni kamroq achchiq qiling. Rahmat.'
        }
      },
      {
        id: 'dlg_019',
        speaker: 'Waiter',
        text: {
          en: 'Anything else? Would you like rice or noodles?',
          zh: zh('还要别的吗？您要米饭还是面条？', 'Hái yào bié de ma? Nín yào mǐfàn háishì miàntiáo?'),
          uz: 'Yana biror nima? Siz guruch yoki lag\'mon xohlaysizmi?'
        }
      },
      {
        id: 'dlg_020',
        speaker: 'Customer',
        text: {
          en: 'Rice, please. That is all for now.',
          zh: zh('请给我米饭。暂时就这些。', 'Qǐng gěi wǒ mǐfàn. Zànshí jiù zhèxiē.'),
          uz: 'Guruch, iltimos. Hozircha shunchalik.'
        }
      },
      {
        id: 'dlg_021',
        speaker: 'Waiter',
        text: {
          en: 'Your order will be ready in about 15 minutes.',
          zh: zh('您的订单大约15分钟后准备好。', 'Nín de dìngdān dàyuē 15 fēnzhōng hòu zhǔnbèi hǎo.'),
          uz: 'Sizning buyurtmangiz taxminan 15 daqiqadan keyin tayyor bo\'ladi.'
        }
      },
      {
        id: 'dlg_022',
        speaker: 'Customer',
        text: {
          en: 'Excuse me, can I have the bill, please?',
          zh: zh('打扰一下，请给我账单。', 'Dǎrǎo yíxià, qǐng gěi wǒ zhàngdān.'),
          uz: 'Kechirasiz, iltimos, hisobni bera olasizmi?'
        }
      }
    ]
  },
  {
    id: 'sc_003',
    title: {
      en: 'At the Hotel',
      zh: zh('在酒店', 'Zài jiǔdiàn'),
      uz: 'Mehmonxonada'
    },
    description: {
      en: 'Checking in and hotel services',
      zh: zh('入住和酒店服务', 'Rùzhù hé jiǔdiàn fúwù'),
      uz: 'Ro\'yxatdan o\'tish va mehmonxona xizmatlari'
    },
    category: 'accommodation',
    introduction: {
      en: 'Essential phrases for hotel stays.',
      zh: zh('酒店住宿的基本短语。', 'Jiǔdiàn zhùsù de jīběn duǎnyǔ.'),
      uz: 'Mehmonxonada qolish uchun zarur iboralar.'
    },
    usefulWords: [
      { en: 'reservation', zh: zh('预订', 'yùdìng'), uz: 'bron' },
      { en: 'room', zh: zh('房间', 'fángjiān'), uz: 'xona' },
      { en: 'key', zh: zh('钥匙', 'yàoshi'), uz: 'kalit' },
      { en: 'breakfast', zh: zh('早餐', 'zǎocān'), uz: 'nonushta' },
      { en: 'wifi', zh: zh('无线网络', 'wúxiàn wǎngluò'), uz: 'wifi' },
      { en: 'checkout', zh: zh('退房', 'tuìfáng'), uz: 'xonadan chiqish' },
      { en: 'elevator', zh: zh('电梯', 'diàntī'), uz: 'lift' },
      { en: 'luggage', zh: zh('行李', 'xínglǐ'), uz: 'yuk' }
    ],
    dialogues: [
      {
        id: 'dlg_023',
        speaker: 'Guest',
        text: {
          en: 'Hello, I have a reservation. My name is John Smith.',
          zh: zh('你好，我有预订。我叫约翰·史密斯。', 'Nǐ hǎo, wǒ yǒu yùdìng. Wǒ jiào Yuēhàn Shǐmìsī.'),
          uz: 'Salom, mening bronim bor. Mening ismim Jon Smit.'
        }
      },
      {
        id: 'dlg_024',
        speaker: 'Receptionist',
        text: {
          en: 'Good afternoon, Mr. Smith. Yes, I found your reservation.',
          zh: zh('下午好，史密斯先生。是的，我找到了您的预订。', 'Xiàwǔ hǎo, Shǐmìsī xiānsheng. Shì de, wǒ zhǎodào le nín de yùdìng.'),
          uz: 'Xayrli kun, mister Smit. Ha, sizning broningizni topdim.'
        }
      },
      {
        id: 'dlg_025',
        speaker: 'Guest',
        text: {
          en: 'What floor is my room on?',
          zh: zh('我的房间在几楼？', 'Wǒ de fángjiān zài jǐ lóu?'),
          uz: 'Mening xonam nechanchi qavatda?' 
        }
      },
      {
        id: 'dlg_026',
        speaker: 'Receptionist',
        text: {
          en: 'Your room is on the 5th floor. The elevator is to your left.',
          zh: zh('您的房间在五楼。电梯在您的左边。', 'Nín de fángjiān zài wǔ lóu. Diàntī zài nín de zuǒbiān.'),
          uz: 'Sizning xonangiz 5-qavatda. Lift sizning chap yoningizda.'
        }
      },
      {
        id: 'dlg_027',
        speaker: 'Guest',
        text: {
          en: 'What time is breakfast served?',
          zh: zh('早餐几点供应？', 'Zǎocān jǐ diǎn gōngyìng?'),
          uz: 'Nonushta soat nechada beriladi?'
        }
      },
      {
        id: 'dlg_028',
        speaker: 'Receptionist',
        text: {
          en: 'Breakfast is from 7 to 10 in the morning in the restaurant.',
          zh: zh('早餐是早上7点到10点在餐厅供应。', 'Zǎocān shì zǎoshang 7 diǎn dào 10 diǎn zài cāntīng gōngyìng.'),
          uz: 'Nonushta ertalabki soat 7 dan 10 gacha restoranda beriladi.'
        }
      },
      {
        id: 'dlg_029',
        speaker: 'Guest',
        text: {
          en: 'Is there WiFi in the room?',
          zh: zh('房间里有无线网络吗？', 'Fángjiān lǐ yǒu wúxiàn wǎngluò ma?'),
          uz: 'Xonada wifi bormi?'
        }
      },
      {
        id: 'dlg_030',
        speaker: 'Receptionist',
        text: {
          en: 'Yes, the WiFi password is on the desk in your room.',
          zh: zh('有的，无线网络密码在您房间的桌子上。', 'Yǒu de, wúxiàn wǎngluò mìmǎ zài nín fángjiān de zhuōzi shàng.'),
          uz: 'Ha, wifi paroli sizning xonangizdagi stolda.'
        }
      },
      {
        id: 'dlg_031',
        speaker: 'Guest',
        text: {
          en: 'What time is checkout?',
          zh: zh('退房时间是几点？', 'Tuìfáng shíjiān shì jǐ diǎn?'),
          uz: 'Xonani bo\'shatish vaqti soat nechada?'
        }
      },
      {
        id: 'dlg_032',
        speaker: 'Receptionist',
        text: {
          en: 'Checkout is at 12 noon. Would you like a wake-up call?',
          zh: zh('退房时间是中午12点。您需要叫醒服务吗？', 'Tuìfáng shíjiān shì zhōngwǔ 12 diǎn. Nín xūyào jiàoxǐng fúwù ma?'),
          uz: 'Xonani bo\'shatish vaqti soat 12 da. Sizga uyg\'otish xizmati kerakmi?'
        }
      }
    ]
  },
  {
    id: 'sc_004',
    title: {
      en: 'Shopping',
      zh: zh('购物', 'Gòuwù'),
      uz: 'Xarid qilish'
    },
    description: {
      en: 'Buying things at a store',
      zh: zh('在商店买东西', 'Zài shāngdiàn mǎi dōngxi'),
      uz: 'Do\'konda narsa sotib olish'
    },
    category: 'shopping',
    introduction: {
      en: 'Useful phrases for shopping and asking about prices.',
      zh: zh('购物和询问价格的有用短语。', 'Gòuwù hé xúnwèn jiàgé de yǒuyòng duǎnyǔ.'),
      uz: 'Xarid qilish va narxlar haqida so\'rash uchun foydali iboralar.'
    },
    usefulWords: [
      { en: 'price', zh: zh('价格', 'jiàgé'), uz: 'narx' },
      { en: 'expensive', zh: zh('贵', 'guì'), uz: 'qimmat' },
      { en: 'cheap', zh: zh('便宜', 'piányi'), uz: 'arzon' },
      { en: 'discount', zh: zh('折扣', 'zhékòu'), uz: 'chegirma' },
      { en: 'size', zh: zh('尺寸', 'chǐcùn'), uz: 'o\'lcham' },
      { en: 'color', zh: zh('颜色', 'yánsè'), uz: 'rang' },
      { en: 'try on', zh: zh('试穿', 'shìchuān'), uz: 'kiyib ko\'rish' },
      { en: 'pay', zh: zh('付款', 'fùkuǎn'), uz: 'to\'lash' }
    ],
    dialogues: [
      {
        id: 'dlg_033',
        speaker: 'Shopper',
        text: {
          en: 'Excuse me, how much is this shirt?',
          zh: zh('打扰一下，这件衬衫多少钱？', 'Dǎrǎo yíxià, zhè jiàn chènshān duōshao qián?'),
          uz: 'Kechirasiz, bu ko\'ylak necha pul?'
        }
      },
      {
        id: 'dlg_034',
        speaker: 'Clerk',
        text: {
          en: 'This shirt is 150 yuan. It is on sale today.',
          zh: zh('这件衬衫150元。今天打折。', 'Zhè jiàn chènshān 150 yuán. Jīntiān dǎzhé.'),
          uz: 'Bu ko\'ylak 150 yuan. Bugun chegirma.'
        }
      },
      {
        id: 'dlg_035',
        speaker: 'Shopper',
        text: {
          en: 'Can I try it on?',
          zh: zh('我可以试穿吗？', 'Wǒ kěyǐ shìchuān ma?'),
          uz: 'Uni kiyib ko\'rsam bo\'ladimi?'
        }
      },
      {
        id: 'dlg_036',
        speaker: 'Clerk',
        text: {
          en: 'Of course! The fitting room is over there.',
          zh: zh('当然可以！试衣间在那边。', 'Dāngrán kěyǐ! Shìyījiān zài nàbiān.'),
          uz: 'Albatta! Kiyinish xonasi ana u yerda.'
        }
      },
      {
        id: 'dlg_037',
        speaker: 'Shopper',
        text: {
          en: 'It fits well. I will take it. Do you have it in blue?',
          zh: zh('很合身。我要了。有蓝色的吗？', 'Hěn héshēn. Wǒ yào le. Yǒu lánsè de ma?'),
          uz: 'U juda mos keldi. Men uni olaman. Ko\'k rangi bormi?'
        }
      },
      {
        id: 'dlg_038',
        speaker: 'Clerk',
        text: {
          en: 'Yes, we have blue in medium and large sizes.',
          zh: zh('有的，我们有中号和大号的蓝色。', 'Yǒu de, wǒmen yǒu zhōnghào hé dàhào de lánsè.'),
          uz: 'Ha, bizda o\'rta va katta o\'lchamdagi ko\'k rangi bor.'
        }
      },
      {
        id: 'dlg_039',
        speaker: 'Shopper',
        text: {
          en: 'I will take the medium size. Can I pay by credit card?',
          zh: zh('我要中号的。可以用信用卡付款吗？', 'Wǒ yào zhōnghào de. Kěyǐ yòng xìnyòngkǎ fùkuǎn ma?'),
          uz: 'Men o\'rta o\'lchamni olaman. Kredit karta bilan to\'lashim mumkinmi?'
        }
      },
      {
        id: 'dlg_040',
        speaker: 'Clerk',
        text: {
          en: 'Yes, we accept all major credit cards.',
          zh: zh('可以，我们接受所有主要的信用卡。', 'Kěyǐ, wǒmen jiēshòu suǒyǒu zhǔyào de xìnyòngkǎ.'),
          uz: 'Ha, biz barcha asosiy kredit kartalarni qabul qilamiz.'
        }
      },
      {
        id: 'dlg_041',
        speaker: 'Shopper',
        text: {
          en: 'Here is my card. Thank you for your help.',
          zh: zh('这是我的卡。谢谢你的帮助。', 'Zhè shì wǒ de kǎ. Xièxiè nǐ de bāngzhù.'),
          uz: 'Mana mening kartam. Yordamingiz uchun rahmat.'
        }
      },
      {
        id: 'dlg_042',
        speaker: 'Clerk',
        text: {
          en: 'You are welcome! Here is your receipt. Have a nice day!',
          zh: zh('不客气！这是您的收据。祝您今天愉快！', 'Bú kèqi! Zhè shì nín de shōujù. Zhù nín jīntiān yúkuài!'),
          uz: 'Arzimaydi! Mana sizning kvitansiyangiz. Yaxshi kun tilayman!'
        }
      }
    ]
  },
  {
    id: 'sc_005',
    title: {
      en: 'Asking for Directions',
      zh: zh('问路', 'Wèn lù'),
      uz: 'Yo\'l so\'rash'
    },
    description: {
      en: 'Finding your way around',
      zh: zh('找到你的路', 'Zhǎodào nǐ de lù'),
      uz: 'O\'z yo\'lingizni topish'
    },
    category: 'travel',
    introduction: {
      en: 'Phrases for asking and giving directions.',
      zh: zh('询问和指路的短语。', 'Xúnwèn hé zhǐlù de duǎnyǔ.'),
      uz: 'Yo\'l so\'rash va ko\'rsatish uchun iboralar.'
    },
    usefulWords: [
      { en: 'left', zh: zh('左', 'zuǒ'), uz: 'chap' },
      { en: 'right', zh: zh('右', 'yòu'), uz: 'o\'ng' },
      { en: 'straight', zh: zh('直', 'zhí'), uz: 'to\'g\'ri' },
      { en: 'corner', zh: zh('拐角', 'guǎijiǎo'), uz: 'burchak' },
      { en: 'traffic light', zh: zh('红绿灯', 'hónglǜdēng'), uz: 'svetofor' },
      { en: 'near', zh: zh('近', 'jìn'), uz: 'yaqin' },
      { en: 'far', zh: zh('远', 'yuǎn'), uz: 'uzoq' },
      { en: 'map', zh: zh('地图', 'dìtú'), uz: 'xarita' }
    ],
    dialogues: [
      {
        id: 'dlg_043',
        speaker: 'Tourist',
        text: {
          en: 'Excuse me, could you tell me how to get to the train station?',
          zh: zh('打扰一下，您能告诉我怎么去火车站吗？', 'Dǎrǎo yíxià, nín néng gàosù wǒ zěnme qù huǒchēzhàn ma?'),
          uz: 'Kechirasiz, menga vokzalga qanday borishni aytib bera olasizmi?'
        }
      },
      {
        id: 'dlg_044',
        speaker: 'Local',
        text: {
          en: 'Sure! Go straight for about 500 meters, then turn left at the traffic light.',
          zh: zh('当然！直走大约500米，然后在红绿灯处左转。', 'Dāngrán! Zhí zǒu dàyuē 500 mǐ, ránhòu zài hónglǜdēng chù zuǒ zhuǎn.'),
          uz: 'Albatta! Taxminan 500 metr to\'g\'ri boring, keyin svetoforda chapga buriling.'
        }
      },
      {
        id: 'dlg_045',
        speaker: 'Tourist',
        text: {
          en: 'Is it far from here?',
          zh: zh('离这里远吗？', 'Lí zhèlǐ yuǎn ma?'),
          uz: 'Bu yerdan uzoqmi?'
        }
      },
      {
        id: 'dlg_046',
        speaker: 'Local',
        text: {
          en: 'No, it is about a 10-minute walk. You will see it on your right.',
          zh: zh('不远，走路大约10分钟。您会看到它在您的右边。', 'Bù yuǎn, zǒulù dàyuē 10 fēnzhōng. Nín huì kàndào tā zài nín de yòubiān.'),
          uz: 'Yo\'q, piyoda taxminan 10 daqiqa. Siz uni o\'ng yoningizda ko\'rasiz.'
        }
      },
      {
        id: 'dlg_047',
        speaker: 'Tourist',
        text: {
          en: 'Thank you very much!',
          zh: zh('非常感谢！', 'Fēicháng gǎnxiè!'),
          uz: 'Katta rahmat!'
        }
      },
      {
        id: 'dlg_048',
        speaker: 'Local',
        text: {
          en: 'You are welcome! If you get lost, just ask someone else.',
          zh: zh('不客气！如果您迷路了，就问别人。', 'Bú kèqi! Rúguǒ nín mílù le, jiù wèn biérén.'),
          uz: 'Arzimaydi! Agar yo\'lingizni yo\'qotib qo\'ysangiz, boshqa birovdan so\'rang.'
        }
      }
    ]
  },
  {
    id: 'sc_006',
    title: {
      en: 'At the Airport',
      zh: zh('在机场', 'Zài jīchǎng'),
      uz: 'Aeroportda'
    },
    description: {
      en: 'Checking in and boarding',
      zh: zh('值机和登机', 'Zhíjī hé dēngjī'),
      uz: 'Ro\'yxatdan o\'tish va bortga chiqish'
    },
    category: 'travel',
    introduction: {
      en: 'Essential phrases for airport procedures.',
      zh: zh('机场手续的基本短语。', 'Jīchǎng shǒuxù de jīběn duǎnyǔ.'),
      uz: 'Aeroport jarayonlari uchun zarur iboralar.'
    },
    usefulWords: [
      { en: 'boarding pass', zh: zh('登机牌', 'dēngjīpái'), uz: 'bort kartasi' },
      { en: 'passport', zh: zh('护照', 'hùzhào'), uz: 'pasport' },
      { en: 'visa', zh: zh('签证', 'qiānzhèng'), uz: 'viza' },
      { en: 'luggage', zh: zh('行李', 'xínglǐ'), uz: 'yuk' },
      { en: 'gate', zh: zh('登机口', 'dēngjīkǒu'), uz: 'bort eshigi' },
      { en: 'delay', zh: zh('延误', 'yánwù'), uz: 'kechikish' },
      { en: 'security', zh: zh('安检', 'ānjiǎn'), uz: 'xavfsizlik' },
      { en: 'customs', zh: zh('海关', 'hǎiguān'), uz: 'bojxona' }
    ],
    dialogues: [
      {
        id: 'dlg_049',
        speaker: 'Passenger',
        text: {
          en: 'Hello, I would like to check in for flight CA981.',
          zh: zh('你好，我想办理CA981航班的值机手续。', 'Nǐ hǎo, wǒ xiǎng bànlǐ CA981 hángbān de zhíjī shǒuxù.'),
          uz: 'Salom, men CA981 reysi uchun ro\'yxatdan o\'tmoqchiman.'
        }
      },
      {
        id: 'dlg_050',
        speaker: 'Agent',
        text: {
          en: 'May I see your passport and ticket, please?',
          zh: zh('请出示您的护照和机票。', 'Qǐng chūshì nín de hùzhào hé jīpiào.'),
          uz: 'Iltimos, pasportingiz va chiptangizni ko\'rsating.'
        }
      },
      {
        id: 'dlg_051',
        speaker: 'Passenger',
        text: {
          en: 'Here they are. How many bags can I check in?',
          zh: zh('给您。我可以托运几个包？', 'Gěi nín. Wǒ kěyǐ tuōyùn jǐ gè bāo?'),
          uz: 'Mana. Men nechta sumkani topshirishim mumkin?'
        }
      },
      {
        id: 'dlg_052',
        speaker: 'Agent',
        text: {
          en: 'You can check in two bags up to 23 kilograms each.',
          zh: zh('您可以托运两个包，每个最多23公斤。', 'Nín kěyǐ tuōyùn liǎng gè bāo, měi gè zuìduō 23 gōngjīn.'),
          uz: 'Siz ikkita sumkani topshirishingiz mumkin, har biri 23 kg gacha.'
        }
      },
      {
        id: 'dlg_053',
        speaker: 'Passenger',
        text: {
          en: 'What gate does the flight depart from?',
          zh: zh('航班从哪个登机口出发？', 'Hángbān cóng nǎge dēngjīkǒu chūfā?'),
          uz: 'Reys qaysi bort eshigidan jo\'naydi?'
        }
      },
      {
        id: 'dlg_054',
        speaker: 'Agent',
        text: {
          en: 'Your flight departs from Gate 15. Boarding starts at 10:30.',
          zh: zh('您的航班从15号登机口出发。10:30开始登机。', 'Nín de hángbān cóng 15 hào dēngjīkǒu chūfā. 10:30 kāishǐ dēngjī.'),
          uz: 'Sizning reysingiz 15-eshikdan jo\'naydi. Bortga chiqish soat 10:30 da boshlanadi.'
        }
      }
    ]
  },
  {
    id: 'sc_007',
    title: {
      en: 'Making a Phone Call',
      zh: zh('打电话', 'Dǎ diànhuà'),
      uz: 'Telefon qilish'
    },
    description: {
      en: 'Talking on the phone',
      zh: zh('在电话上交谈', 'Zài diànhuà shàng jiāotán'),
      uz: 'Telefonda gaplashish'
    },
    category: 'conversation',
    introduction: {
      en: 'Phrases for phone conversations.',
      zh: zh('电话交谈的短语。', 'Diànhuà jiāotán de duǎnyǔ.'),
      uz: 'Telefon suhbatlari uchun iboralar.'
    },
    usefulWords: [
      { en: 'call', zh: zh('打电话', 'dǎ diànhuà'), uz: 'qo\'ng\'iroq' },
      { en: 'message', zh: zh('留言', 'liúyán'), uz: 'xabar' },
      { en: 'number', zh: zh('号码', 'hàomǎ'), uz: 'raqam' },
      { en: 'busy', zh: zh('忙', 'máng'), uz: 'band' },
      { en: 'available', zh: zh('有空', 'yǒu kòng'), uz: 'bo\'sh' },
      { en: 'call back', zh: zh('回电话', 'huí diànhuà'), uz: 'qayta qo\'ng\'iroq' },
      { en: 'wrong number', zh: zh('打错了', 'dǎ cuò le'), uz: 'noto\'g\'ri raqam' },
      { en: 'speak', zh: zh('说话', 'shuōhuà'), uz: 'gapirish' }
    ],
    dialogues: [
      {
        id: 'dlg_055',
        speaker: 'Caller',
        text: {
          en: 'Hello, may I speak to Mr. Wang?',
          zh: zh('你好，我可以和王先生说话吗？', 'Nǐ hǎo, wǒ kěyǐ hé Wáng xiānsheng shuōhuà ma?'),
          uz: 'Salom, men Vang bilan gaplasha olamanmi?'
        }
      },
      {
        id: 'dlg_056',
        speaker: 'Receiver',
        text: {
          en: 'I am sorry, Mr. Wang is not available right now.',
          zh: zh('对不起，王先生现在没空。', 'Duìbùqǐ, Wáng xiānsheng xiànzài méi kòng.'),
          uz: 'Kechirasiz, Vang hozir band.'
        }
      },
      {
        id: 'dlg_057',
        speaker: 'Caller',
        text: {
          en: 'Can I leave a message?',
          zh: zh('我可以留言吗？', 'Wǒ kěyǐ liúyán ma?'),
          uz: 'Xabar qoldira olamanmi?'
        }
      },
      {
        id: 'dlg_058',
        speaker: 'Receiver',
        text: {
          en: 'Of course. What would you like me to tell him?',
          zh: zh('当然可以。您想让我告诉他什么？', 'Dāngrán kěyǐ. Nín xiǎng ràng wǒ gàosù tā shénme?'),
          uz: 'Albatta. Unga nima aytishimni xohlaysiz?'
        }
      },
      {
        id: 'dlg_059',
        speaker: 'Caller',
        text: {
          en: 'Please tell him to call me back. My number is 138-1234-5678.',
          zh: zh('请让他给我回电话。我的号码是138-1234-5678。', 'Qǐng ràng tā gěi wǒ huí diànhuà. Wǒ de hàomǎ shì 138-1234-5678.'),
          uz: 'Iltimos, menga qayta qo\'ng\'iroq qilishini ayting. Mening raqamim 138-1234-5678.'
        }
      },
      {
        id: 'dlg_060',
        speaker: 'Receiver',
        text: {
          en: 'I will give him the message. Goodbye!',
          zh: zh('我会转告他的。再见！', 'Wǒ huì zhuǎngào tā de. Zàijiàn!'),
          uz: 'Men uni xabardor qilaman. Xayr!'
        }
      }
    ]
  },
  {
    id: 'sc_008',
    title: {
      en: 'At the Doctor',
      zh: zh('看医生', 'Kàn yīshēng'),
      uz: 'Doktorga borish'
    },
    description: {
      en: 'Describing symptoms and getting treatment',
      zh: zh('描述症状和接受治疗', 'Miáoshù zhèngzhuàng hé jiēshòu zhìliáo'),
      uz: 'Alomatlarini tavsiflash va davolanish'
    },
    category: 'health',
    introduction: {
      en: 'Medical phrases for doctor visits.',
      zh: zh('看医生的医疗短语。', 'Kàn yīshēng de yīliáo duǎnyǔ.'),
      uz: 'Doktorga tashrif uchun tibbiy iboralar.'
    },
    usefulWords: [
      { en: 'pain', zh: zh('疼痛', 'téngtòng'), uz: 'og\'riq' },
      { en: 'fever', zh: zh('发烧', 'fāshāo'), uz: 'isitma' },
      { en: 'cough', zh: zh('咳嗽', 'késou'), uz: 'yo\'tal' },
      { en: 'medicine', zh: zh('药', 'yào'), uz: 'dori' },
      { en: 'allergy', zh: zh('过敏', 'guòmǐn'), uz: 'allergiya' },
      { en: 'prescription', zh: zh('处方', 'chǔfāng'), uz: 'retsept' },
      { en: 'rest', zh: zh('休息', 'xiūxi'), uz: 'dam olish' },
      { en: 'appointment', zh: zh('预约', 'yùyuē'), uz: 'uchrashuv' }
    ],
    dialogues: [
      {
        id: 'dlg_061',
        speaker: 'Doctor',
        text: {
          en: 'Good morning. What seems to be the problem?',
          zh: zh('早上好。您哪里不舒服？', 'Zǎoshang hǎo. Nín nǎlǐ bù shūfu?'),
          uz: 'Xayrli tong. Sizni nima bezovta qilyapti?'
        }
      },
      {
        id: 'dlg_062',
        speaker: 'Patient',
        text: {
          en: 'I have a terrible headache and I feel dizzy.',
          zh: zh('我头痛得厉害，而且觉得头晕。', 'Wǒ tóutòng de lìhai, érqiě juéde tóuyūn.'),
          uz: 'Boshim juda og\'riyapti va boshim aylanayapti.'
        }
      },
      {
        id: 'dlg_063',
        speaker: 'Doctor',
        text: {
          en: 'How long have you had these symptoms?',
          zh: zh('您有这些症状多久了？', 'Nín yǒu zhèxiē zhèngzhuàng duōjiǔ le?'),
          uz: 'Bu alomatlar qancha vaqt davom etmoqda?'
        }
      },
      {
        id: 'dlg_064',
        speaker: 'Patient',
        text: {
          en: 'Since yesterday. I also have a slight fever.',
          zh: zh('从昨天开始。我还有点发烧。', 'Cóng zuótiān kāishǐ. Wǒ hái yǒudiǎn fāshāo.'),
          uz: 'Kechadan beri. Menda biroz isitma ham bor.'
        }
      },
      {
        id: 'dlg_065',
        speaker: 'Doctor',
        text: {
          en: 'Let me check your temperature. Please open your mouth.',
          zh: zh('让我量一下您的体温。请张开嘴。', 'Ràng wǒ liáng yíxià nín de tǐwēn. Qǐng zhāng kāi zuǐ.'),
          uz: 'Keling, haroratingizni o\'lchaylik. Iltimos, og\'izingizni oching.'
        }
      },
      {
        id: 'dlg_066',
        speaker: 'Doctor',
        text: {
          en: 'You have a fever of 38 degrees. I will prescribe some medicine.',
          zh: zh('您发烧38度。我给您开一些药。', 'Nín fāshāo 38 dù. Wǒ gěi nín kāi yìxiē yào.'),
          uz: 'Sizda 38 daraja isitma bor. Sizga bir dorilar yozib beraman.'
        }
      },
      {
        id: 'dlg_067',
        speaker: 'Patient',
        text: {
          en: 'Thank you, doctor. How often should I take the medicine?',
          zh: zh('谢谢您，医生。这药我应该多久吃一次？', 'Xièxiè nín, yīshēng. Zhè yào wǒ yīnggāi duōjiǔ chī yí cì?'),
          uz: 'Rahmat, doktor. Bu dorini qanchalik tez-tez qabul qilishim kerak?'
        }
      },
      {
        id: 'dlg_068',
        speaker: 'Doctor',
        text: {
          en: 'Take it three times a day after meals. And get plenty of rest.',
          zh: zh('一天三次，饭后吃。还要多休息。', 'Yì tiān sān cì, fànhòu chī. Hái yào duō xiūxi.'),
          uz: 'Kuniga uch marta, ovqatdan keyin. Va ko\'p dam oling.'
        }
      }
    ]
  }
];

// Completion tracking functions
export const getCompletedConversations = (): string[] => {
  if (typeof window === 'undefined') return [];
  const saved = localStorage.getItem('completedConversations');
  return saved ? JSON.parse(saved) : [];
};

export const markConversationCompleted = (id: string) => {
  if (typeof window === 'undefined') return;
  const completed = getCompletedConversations();
  if (!completed.includes(id)) {
    completed.push(id);
    localStorage.setItem('completedConversations', JSON.stringify(completed));
  }
};

export const isConversationCompleted = (id: string): boolean => {
  return getCompletedConversations().includes(id);
};

export const getCompletionProgress = () => {
  const completed = getCompletedConversations();
  const total = conversationScenarios.length;
  return {
    completed: completed.length,
    total,
    percentage: Math.round((completed.length / total) * 100)
  };
};

export const clearCompletedConversations = () => {
  if (typeof window === 'undefined') return;
  localStorage.removeItem('completedConversations');
};
