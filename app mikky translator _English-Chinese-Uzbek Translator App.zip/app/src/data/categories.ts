import type { CategoryInfo } from '@/types';

export const categories: CategoryInfo[] = [
  {
    id: 'greetings',
    name: {
      en: 'Greetings',
      zh: '问候',
      uz: 'Salomlashish'
    },
    icon: 'Hand',
    color: '#A8E6CF'
  },
  {
    id: 'food',
    name: {
      en: 'Food',
      zh: '食物',
      uz: 'Oziq-ovqat'
    },
    icon: 'UtensilsCrossed',
    color: '#FFB7C5'
  },
  {
    id: 'travel',
    name: {
      en: 'Travel',
      zh: '旅行',
      uz: 'Sayohat'
    },
    icon: 'Plane',
    color: '#A0C4FF'
  },
  {
    id: 'shopping',
    name: {
      en: 'Shopping',
      zh: '购物',
      uz: 'Xarid'
    },
    icon: 'ShoppingBag',
    color: '#D0F0A8'
  },
  {
    id: 'health',
    name: {
      en: 'Health',
      zh: '健康',
      uz: 'Sog\'liq'
    },
    icon: 'Heart',
    color: '#FFB7C5'
  },
  {
    id: 'work',
    name: {
      en: 'Work',
      zh: '工作',
      uz: 'Ish'
    },
    icon: 'Briefcase',
    color: '#A8E6CF'
  },
  {
    id: 'family',
    name: {
      en: 'Family',
      zh: '家庭',
      uz: 'Oila'
    },
    icon: 'Users',
    color: '#FFD166'
  },
  {
    id: 'numbers',
    name: {
      en: 'Numbers',
      zh: '数字',
      uz: 'Raqamlar'
    },
    icon: 'Hash',
    color: '#A0C4FF'
  },
  {
    id: 'time',
    name: {
      en: 'Time',
      zh: '时间',
      uz: 'Vaqt'
    },
    icon: 'Clock',
    color: '#D0F0A8'
  },
  {
    id: 'weather',
    name: {
      en: 'Weather',
      zh: '天气',
      uz: 'Ob-havo'
    },
    icon: 'Cloud',
    color: '#A0C4FF'
  },
  {
    id: 'emotions',
    name: {
      en: 'Emotions',
      zh: '情感',
      uz: 'His-tuyg\'ular'
    },
    icon: 'Smile',
    color: '#FFD166'
  },
  {
    id: 'colors',
    name: {
      en: 'Colors',
      zh: '颜色',
      uz: 'Ranglar'
    },
    icon: 'Palette',
    color: '#FFB7C5'
  },
  {
    id: 'directions',
    name: {
      en: 'Directions',
      zh: '方向',
      uz: 'Yo\'nalishlar'
    },
    icon: 'MapPin',
    color: '#A8E6CF'
  },
  {
    id: 'transportation',
    name: {
      en: 'Transport',
      zh: '交通',
      uz: 'Transport'
    },
    icon: 'Bus',
    color: '#A0C4FF'
  },
  {
    id: 'accommodation',
    name: {
      en: 'Hotel',
      zh: '住宿',
      uz: 'Turar joy'
    },
    icon: 'Home',
    color: '#D0F0A8'
  },
  {
    id: 'restaurant',
    name: {
      en: 'Restaurant',
      zh: '餐厅',
      uz: 'Restoran'
    },
    icon: 'Coffee',
    color: '#FFB7C5'
  },
  {
    id: 'emergency',
    name: {
      en: 'Emergency',
      zh: '紧急',
      uz: 'Favqulodda'
    },
    icon: 'AlertCircle',
    color: '#FF6A3D'
  },
  {
    id: 'conversation',
    name: {
      en: 'Conversation',
      zh: '对话',
      uz: 'Suhbat'
    },
    icon: 'MessageCircle',
    color: '#FFD166'
  }
];
