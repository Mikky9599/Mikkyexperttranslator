import { useState, useCallback, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Home, Heart, MessageCircle, Settings, Search, Volume2, 
  Copy, ChevronLeft, Star, BookOpen, Globe, Mic, X,
  Hand, UtensilsCrossed, Plane, ShoppingBag, Briefcase,
  MapPin, Clock, Cloud, Smile, Palette, Bus, Coffee,
  AlertCircle, Hash, Users
} from 'lucide-react';
import type { WordEntry, Language, Category } from '@/types';
import { wordDatabase, databaseStats } from '@/data/database';
import { conversationScenarios, markConversationCompleted, isConversationCompleted, getCompletionProgress } from '@/data/conversations';
import { categories } from '@/data/categories';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { toast } from 'sonner';

// Animation variants
const stickerTransition = {
  type: 'spring' as const,
  stiffness: 260,
  damping: 18,
  mass: 1,
};

const popIn = {
  initial: { scale: 0.6, opacity: 0 },
  animate: { scale: 1, opacity: 1 },
  exit: { scale: 0.8, opacity: 0 },
  transition: stickerTransition,
};

const slideInUp = {
  initial: { y: 24, opacity: 0 },
  animate: { y: 0, opacity: 1 },
  exit: { y: -24, opacity: 0 },
  transition: { type: 'spring' as const, stiffness: 260, damping: 18, mass: 1, staggerChildren: 0.06 },
};

const slideInDown = {
  initial: { y: -24, opacity: 0 },
  animate: { y: 0, opacity: 1 },
  exit: { y: 24, opacity: 0 },
  transition: stickerTransition,
};

const slideInRight = {
  initial: { x: 24, opacity: 0 },
  animate: { x: 0, opacity: 1 },
  exit: { x: -24, opacity: 0 },
  transition: stickerTransition,
};

// Icon mapping
const iconMap: Record<string, React.ElementType> = {
  Hand, UtensilsCrossed, Plane, ShoppingBag, Heart, Briefcase,
  Users, Hash, Clock, Cloud, Smile, Palette, MapPin, Bus, Coffee,
  Home, AlertCircle, MessageCircle, BookOpen, Globe
};

// Language names
const languageNames: Record<Language, Record<Language, string>> = {
  en: { en: 'English', zh: 'English', uz: 'English' },
  zh: { en: 'Chinese', zh: '中文', uz: 'Xitoycha' },
  uz: { en: 'Uzbek', zh: '乌兹别克语', uz: 'O\'zbekcha' },
};

// Background images for each language
const backgroundImages: Record<Language, string> = {
  en: '/america.jpg',
  zh: '/greatwall.jpg',
  uz: '/tashkent.jpg',
};

// Main App Component
function App() {
  const [currentScreen, setCurrentScreen] = useState<'onboarding' | 'home' | 'detail' | 'favorites' | 'quiz' | 'settings' | 'conversation' | 'conversationDetail'>('onboarding');
  const [baseLanguage, setBaseLanguage] = useLocalStorage<Language>('baseLanguage', 'en');
  const [favorites, setFavorites] = useLocalStorage<string[]>('favorites', []);
  const [selectedEntry, setSelectedEntry] = useState<WordEntry | null>(null);
  const [selectedConversation, setSelectedConversation] = useState<typeof conversationScenarios[0] | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const [quizQuestions, setQuizQuestions] = useState<WordEntry[]>([]);
  const [currentQuizIndex, setCurrentQuizIndex] = useState(0);
  const [quizScore, setQuizScore] = useState(0);
  const [showQuizResult, setShowQuizResult] = useState(false);

  // Filter words based on search and category
  const filteredWords = useMemo(() => {
    let words = wordDatabase;
    
    if (selectedCategory) {
      words = words.filter(w => w.category === selectedCategory);
    }
    
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      words = words.filter(w => 
        w.translations.en.toLowerCase().includes(query) ||
        w.translations.zh.toLowerCase().includes(query) ||
        w.translations.uz.toLowerCase().includes(query)
      );
    }
    
    return words.slice(0, 50);
  }, [searchQuery, selectedCategory]);

  // Get favorite entries
  const favoriteEntries = useMemo(() => {
    return wordDatabase.filter(w => favorites.includes(w.id));
  }, [favorites]);

  // Toggle favorite
  const toggleFavorite = useCallback((entryId: string) => {
    setFavorites(prev => {
      if (prev.includes(entryId)) {
        toast.success('Removed from favorites');
        return prev.filter(id => id !== entryId);
      } else {
        toast.success('Added to favorites');
        return [...prev, entryId];
      }
    });
  }, [setFavorites]);

  // Copy to clipboard
  const copyToClipboard = useCallback((text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard');
  }, []);

  // Text to speech
  const speakText = useCallback((text: string, lang: Language) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      const langMap: Record<Language, string> = { en: 'en-US', zh: 'zh-CN', uz: 'uz-UZ' };
      utterance.lang = langMap[lang];
      speechSynthesis.speak(utterance);
    } else {
      toast.error('Text-to-speech not supported');
    }
  }, []);

  // Start quiz
  const startQuiz = useCallback(() => {
    const shuffled = [...wordDatabase].sort(() => Math.random() - 0.5);
    setQuizQuestions(shuffled.slice(0, 10));
    setCurrentQuizIndex(0);
    setQuizScore(0);
    setShowQuizResult(false);
    setCurrentScreen('quiz');
  }, []);

  // Handle quiz answer
  const handleQuizAnswer = useCallback((answer: string, correctAnswer: string) => {
    if (answer === correctAnswer) {
      setQuizScore(prev => prev + 1);
      toast.success('Correct!');
    } else {
      toast.error('Try again!');
    }
    
    setTimeout(() => {
      if (currentQuizIndex < quizQuestions.length - 1) {
        setCurrentQuizIndex(prev => prev + 1);
      } else {
        setShowQuizResult(true);
      }
    }, 1000);
  }, [currentQuizIndex, quizQuestions.length]);

  // Onboarding Screen
  const OnboardingScreen = () => (
    <motion.div 
      className="min-h-screen relative flex flex-col items-center justify-center px-6 py-8 overflow-hidden"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center transition-all duration-700"
        style={{ 
          backgroundImage: `url(${backgroundImages[baseLanguage]})`,
        }}
      />
      {/* Dark overlay */}
      <div className="absolute inset-0 bg-black/50" />
      
      <div className="w-full max-w-sm z-10">
        {/* Logo Image */}
        <motion.div 
          className="flex flex-col items-center mb-6"
          {...popIn}
        >
          <img 
            src="/mikkylogo.png" 
            alt="MikkyExpert" 
            className="w-32 h-32 object-contain drop-shadow-2xl"
          />
        </motion.div>
        
        {/* Tagline */}
        <motion.p 
          className="text-center text-white/90 text-lg font-bold mb-8 tracking-wider"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          JUST ENJOY BY TALKING
        </motion.p>
        
        {/* Language selector */}
        <motion.div 
          className="mb-8"
          {...slideInUp}
        >
          <p className="text-white/80 text-center text-sm mb-4 font-medium">
            Choose your language
          </p>
          <div className="flex gap-3 justify-center">
            {(['en', 'zh', 'uz'] as Language[]).map((lang) => (
              <motion.button
                key={lang}
                onClick={() => setBaseLanguage(lang)}
                className={`px-4 py-2 rounded-full border-[2px] border-white/50 font-semibold text-sm backdrop-blur-sm transition-all ${baseLanguage === lang ? 'bg-yellow-400 text-black border-yellow-400' : 'bg-white/20 text-white hover:bg-white/30'}`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {lang === 'en' ? 'English' : lang === 'zh' ? '中文' : 'O\'zbek'}
              </motion.button>
            ))}
          </div>
        </motion.div>
        
        {/* CTA Button */}
        <motion.button
          onClick={() => setCurrentScreen('home')}
          className="w-full h-14 rounded-[18px] border-[3px] border-white/50 font-bold text-base bg-yellow-400 text-black backdrop-blur-sm"
          style={{ boxShadow: '0 6px 20px rgba(0,0,0,0.3)' }}
          {...slideInUp}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          Get Started
        </motion.button>
        
        <motion.p 
          className="text-white/60 text-center text-xs mt-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
        >
          Made by MikkyExpert
        </motion.p>
      </div>
    </motion.div>
  );

  // Home Screen
  const HomeScreen = () => (
    <motion.div 
      className="min-h-screen bg-red-500 pb-24"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <div className="sticky top-0 z-20 bg-red-500 safe-area-top">
        <div className="px-4 py-4">
          <motion.div 
            className="bg-white rounded-[22px] border-[3px] border-[#1A1A2E]/85 p-3 flex items-center gap-3"
            style={{ boxShadow: '0 10px 0 rgba(26, 26, 46, 0.85)' }}
            {...slideInDown}
          >
            <Search className="w-5 h-5 text-gray-500" />
            <input
              type="text"
              placeholder="Search words or phrases..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1 bg-transparent outline-none text-[#1A1A2E] placeholder:text-gray-400 text-sm"
            />
            {searchQuery && (
              <button onClick={() => setSearchQuery('')}>
                <X className="w-5 h-5 text-gray-500" />
              </button>
            )}
            <button className="p-1">
              <Mic className="w-5 h-5 text-gray-500" />
            </button>
          </motion.div>
        </div>
        
        <div className="px-4 pb-4">
          <p className="text-white font-bold text-sm mb-3">Categories</p>
          <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-2">
            <motion.button
              onClick={() => setSelectedCategory(null)}
              className={`px-4 py-2 rounded-full border-[2px] border-[#1A1A2E]/85 font-semibold text-sm whitespace-nowrap ${selectedCategory === null ? 'bg-yellow-300' : 'bg-white text-red-500'}`}
              style={{ boxShadow: '0 4px 0 rgba(26, 26, 46, 0.85)' }}
              whileTap={{ scale: 0.95 }}
            >
              All
            </motion.button>
            {categories.map((cat, index) => {
              const Icon = iconMap[cat.icon] || Globe;
              return (
                <motion.button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-4 py-2 rounded-full border-[2px] border-[#1A1A2E]/85 font-semibold text-sm flex items-center gap-1 whitespace-nowrap ${selectedCategory === cat.id ? 'bg-yellow-300' : ''}`}
                  style={{ 
                    background: selectedCategory === cat.id ? undefined : cat.color,
                    boxShadow: '0 4px 0 rgba(26, 26, 46, 0.85)'
                  }}
                  {...slideInRight}
                  transition={{ delay: index * 0.06 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Icon className="w-3 h-3" />
                  {cat.name[baseLanguage]}
                </motion.button>
              );
            })}
          </div>
        </div>
      </div>
      
      <div className="px-4">
        <p className="text-white font-bold text-sm mb-3">
          {searchQuery ? 'Search Results' : selectedCategory ? 'Category Results' : 'Recent'}
        </p>
        <div className="space-y-3">
          <AnimatePresence mode="popLayout">
            {filteredWords.map((entry, index) => (
              <motion.div
                key={entry.id}
                className="bg-white rounded-[22px] border-[3px] border-[#1A1A2E]/85 p-4 cursor-pointer"
                style={{ boxShadow: '0 10px 0 rgba(26, 26, 46, 0.85)' }}
                {...slideInUp}
                transition={{ delay: index * 0.08 }}
                whileHover={{ scale: 1.01, y: -2 }}
                whileTap={{ scale: 0.99 }}
                onClick={() => {
                  setSelectedEntry(entry);
                  setCurrentScreen('detail');
                }}
                layout
              >
                <div className="flex justify-between items-start">
                  <div>
                    <p className="font-bold text-[#1A1A2E] text-lg">{entry.translations[baseLanguage]}</p>
                    <p className="text-gray-500 text-sm mt-1">
                      {entry.translations[baseLanguage === 'en' ? 'zh' : baseLanguage === 'zh' ? 'uz' : 'en']}
                    </p>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFavorite(entry.id);
                    }}
                    className="p-2"
                  >
                    <Heart 
                      className={`w-5 h-5 ${favorites.includes(entry.id) ? 'fill-red-500 text-red-500' : 'text-gray-400'}`} 
                    />
                  </button>
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <span 
                    className="text-xs px-2 py-1 rounded-full font-semibold"
                    style={{ 
                      background: categories.find(c => c.id === entry.category)?.color || '#FDF6E3',
                      color: '#1A1A2E'
                    }}
                  >
                    {categories.find(c => c.id === entry.category)?.name[baseLanguage]}
                  </span>
                  <span className="text-xs text-gray-500 capitalize">{entry.difficulty}</span>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
        
        {filteredWords.length === 0 && (
          <motion.div 
            className="bg-white rounded-[22px] border-[3px] border-[#1A1A2E]/85 p-8 text-center"
            style={{ boxShadow: '0 10px 0 rgba(26, 26, 46, 0.85)' }}
            {...popIn}
          >
            <p className="text-gray-500">No results found</p>
            <p className="text-sm text-gray-400 mt-1">Try a different search term</p>
          </motion.div>
        )}
      </div>
    </motion.div>
  );

  // Detail Screen
  const DetailScreen = () => {
    if (!selectedEntry) return null;
    
    const otherLangs = (['en', 'zh', 'uz'] as Language[]).filter(l => l !== baseLanguage);
    
    return (
      <motion.div 
        className="min-h-screen bg-red-500 pb-24"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <div className="sticky top-0 z-20 bg-red-500 safe-area-top px-4 py-4 flex items-center gap-3">
          <motion.button
            onClick={() => setCurrentScreen('home')}
            className="w-10 h-10 bg-white rounded-full border-[3px] border-[#1A1A2E]/85 flex items-center justify-center"
            style={{ boxShadow: '0 4px 0 rgba(26, 26, 46, 0.85)' }}
            whileTap={{ scale: 0.95 }}
          >
            <ChevronLeft className="w-5 h-5 text-[#1A1A2E]" />
          </motion.button>
          <h2 className="text-white font-bold text-lg flex-1">Word Detail</h2>
          <button
            onClick={() => toggleFavorite(selectedEntry.id)}
            className="w-10 h-10 bg-white rounded-full border-[3px] border-[#1A1A2E]/85 flex items-center justify-center"
            style={{ boxShadow: '0 4px 0 rgba(26, 26, 46, 0.85)' }}
          >
            <Heart 
              className={`w-5 h-5 ${favorites.includes(selectedEntry.id) ? 'fill-red-500 text-red-500' : 'text-[#1A1A2E]'}`} 
            />
          </button>
        </div>
        
        <div className="px-4 space-y-4">
          <motion.div 
            className="bg-white rounded-[22px] border-[3px] border-[#1A1A2E]/85 p-6"
            style={{ boxShadow: '0 10px 0 rgba(26, 26, 46, 0.85)' }}
            {...popIn}
          >
            <p className="text-gray-500 text-xs font-bold uppercase tracking-wider mb-2">
              {languageNames[baseLanguage][baseLanguage]}
            </p>
            <p className="text-3xl font-black text-[#1A1A2E] mb-4">{selectedEntry.translations[baseLanguage]}</p>
            
            {selectedEntry.translations[`${baseLanguage}Pronunciation` as keyof typeof selectedEntry.translations] && (
              <p className="text-gray-500 text-sm mb-4">
                /{selectedEntry.translations[`${baseLanguage}Pronunciation` as keyof typeof selectedEntry.translations]}/
              </p>
            )}
            
            <button
              onClick={() => speakText(selectedEntry.translations[baseLanguage], baseLanguage)}
              className="flex items-center gap-2 px-4 py-2 bg-blue-200 rounded-full border-[2px] border-[#1A1A2E]/85 text-sm font-semibold"
            >
              <Volume2 className="w-4 h-4" />
              Listen
            </button>
          </motion.div>
          
          {otherLangs.map((lang, index) => (
            <motion.div 
              key={lang}
              className="bg-green-200 rounded-[18px] border-[3px] border-[#1A1A2E]/85 p-4"
              style={{ boxShadow: '0 6px 0 rgba(26, 26, 46, 0.85)' }}
              {...slideInUp}
              transition={{ delay: (index + 1) * 0.1 }}
            >
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-gray-500 text-xs font-bold uppercase tracking-wider mb-1">
                    {languageNames[lang][baseLanguage]}
                  </p>
                  <p className="text-xl font-bold text-[#1A1A2E]">{selectedEntry.translations[lang]}</p>
                  {selectedEntry.translations[`${lang}Pronunciation` as keyof typeof selectedEntry.translations] && (
                    <p className="text-gray-500 text-sm mt-1">
                      /{selectedEntry.translations[`${lang}Pronunciation` as keyof typeof selectedEntry.translations]}/
                    </p>
                  )}
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => speakText(selectedEntry.translations[lang], lang)}
                    className="w-8 h-8 bg-white rounded-full border-[2px] border-[#1A1A2E]/85 flex items-center justify-center"
                  >
                    <Volume2 className="w-4 h-4 text-[#1A1A2E]" />
                  </button>
                  <button
                    onClick={() => copyToClipboard(selectedEntry.translations[lang])}
                    className="w-8 h-8 bg-white rounded-full border-[2px] border-[#1A1A2E]/85 flex items-center justify-center"
                  >
                    <Copy className="w-4 h-4 text-[#1A1A2E]" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
          
          <motion.div 
            className="bg-blue-200 rounded-[18px] border-[3px] border-[#1A1A2E]/85 p-4"
            style={{ boxShadow: '0 6px 0 rgba(26, 26, 46, 0.85)' }}
            {...slideInUp}
            transition={{ delay: 0.3 }}
          >
            <p className="text-gray-500 text-xs font-bold uppercase tracking-wider mb-2">Example</p>
            <p className="text-[#1A1A2E] font-medium mb-2">{selectedEntry.example[baseLanguage]}</p>
            <p className="text-gray-500 text-sm">{selectedEntry.example[otherLangs[0]]}</p>
            <button
              onClick={() => speakText(selectedEntry.example[baseLanguage], baseLanguage)}
              className="flex items-center gap-2 mt-3 px-3 py-1.5 bg-white rounded-full border-[2px] border-[#1A1A2E]/85 text-xs font-semibold"
            >
              <Volume2 className="w-3 h-3" />
              Listen
            </button>
          </motion.div>
          
          <motion.div 
            className="flex flex-wrap gap-2"
            {...slideInUp}
            transition={{ delay: 0.4 }}
          >
            {selectedEntry.tags.map(tag => (
              <span 
                key={tag}
                className="px-3 py-1 bg-green-200 rounded-full text-xs font-semibold text-[#1A1A2E] border-[2px] border-[#1A1A2E]/85"
              >
                #{tag}
              </span>
            ))}
          </motion.div>
        </div>
      </motion.div>
    );
  };

  // Favorites Screen
  const FavoritesScreen = () => (
    <motion.div 
      className="min-h-screen bg-red-500 pb-24"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <div className="px-4 py-6 safe-area-top">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-white font-black text-2xl">Your Favorites</h2>
          <span className="bg-yellow-300 px-3 py-1 rounded-full text-sm font-bold border-[2px] border-[#1A1A2E]/85">
            {favoriteEntries.length}
          </span>
        </div>
        
        {favoriteEntries.length === 0 ? (
          <motion.div 
            className="bg-white rounded-[22px] border-[3px] border-[#1A1A2E]/85 p-8 text-center"
            style={{ boxShadow: '0 10px 0 rgba(26, 26, 46, 0.85)' }}
            {...popIn}
          >
            <Heart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-[#1A1A2E] font-bold text-lg mb-2">No favorites yet</p>
            <p className="text-gray-500 text-sm">Tap the heart icon to save words you want to remember</p>
          </motion.div>
        ) : (
          <div className="space-y-3">
            <AnimatePresence mode="popLayout">
              {favoriteEntries.map((entry, index) => (
                <motion.div
                  key={entry.id}
                  className="bg-white rounded-[22px] border-[3px] border-[#1A1A2E]/85 p-4 cursor-pointer"
                  style={{ boxShadow: '0 10px 0 rgba(26, 26, 46, 0.85)' }}
                  {...slideInUp}
                  transition={{ delay: index * 0.06 }}
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.99 }}
                  onClick={() => {
                    setSelectedEntry(entry);
                    setCurrentScreen('detail');
                  }}
                  layout
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-bold text-[#1A1A2E] text-lg">{entry.translations[baseLanguage]}</p>
                      <p className="text-gray-500 text-sm mt-1">
                        {entry.translations[baseLanguage === 'en' ? 'zh' : baseLanguage === 'zh' ? 'uz' : 'en']}
                      </p>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleFavorite(entry.id);
                      }}
                      className="p-2"
                    >
                      <Heart className="w-5 h-5 fill-red-500 text-red-500" />
                    </button>
                  </div>
                  <div className="flex items-center gap-2 mt-2">
                    <span 
                      className="text-xs px-2 py-1 rounded-full font-semibold"
                      style={{ 
                        background: categories.find(c => c.id === entry.category)?.color || '#FDF6E3',
                        color: '#1A1A2E'
                      }}
                    >
                      {categories.find(c => c.id === entry.category)?.name[baseLanguage]}
                    </span>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>
    </motion.div>
  );

  // Quiz Screen
  const QuizScreen = () => {
    if (quizQuestions.length === 0) {
      return (
        <motion.div 
          className="min-h-screen bg-red-500 flex flex-col items-center justify-center px-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.div 
            className="bg-white rounded-[22px] border-[3px] border-[#1A1A2E]/85 p-8 text-center max-w-sm"
            style={{ boxShadow: '0 10px 0 rgba(26, 26, 46, 0.85)' }}
            {...popIn}
          >
            <Star className="w-16 h-16 text-yellow-400 mx-auto mb-4" />
            <h2 className="text-2xl font-black text-[#1A1A2E] mb-2">Practice Mode</h2>
            <p className="text-gray-500 mb-6">Test your knowledge</p>
            <button
              onClick={startQuiz}
              className="w-full h-14 rounded-[18px] border-[3px] border-[#1A1A2E]/85 font-bold text-base bg-yellow-300 text-[#1A1A2E]"
              style={{ boxShadow: '0 6px 0 rgba(26, 26, 46, 0.85)' }}
            >
              Start Quiz
            </button>
            <button
              onClick={() => setCurrentScreen('home')}
              className="w-full mt-3 py-3 text-[#1A1A2E] font-semibold"
            >
              Back to Home
            </button>
          </motion.div>
        </motion.div>
      );
    }
    
    if (showQuizResult) {
      return (
        <motion.div 
          className="min-h-screen bg-red-500 flex flex-col items-center justify-center px-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.div 
            className="bg-white rounded-[22px] border-[3px] border-[#1A1A2E]/85 p-8 text-center max-w-sm z-10"
            style={{ boxShadow: '0 10px 0 rgba(26, 26, 46, 0.85)' }}
            {...popIn}
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', stiffness: 200, damping: 15 }}
            >
              <Star className="w-20 h-20 text-yellow-400 mx-auto mb-4" />
            </motion.div>
            <h2 className="text-3xl font-black text-[#1A1A2E] mb-2">Great job!</h2>
            <p className="text-gray-500 mb-4">
              You got <span className="font-bold text-red-500">{quizScore}</span> correct
            </p>
            <div className="bg-yellow-200 rounded-full h-4 mb-6 overflow-hidden border-[2px] border-[#1A1A2E]/85">
              <motion.div 
                className="h-full bg-red-500"
                initial={{ width: 0 }}
                animate={{ width: `${(quizScore / quizQuestions.length) * 100}%` }}
                transition={{ duration: 0.5, delay: 0.3 }}
              />
            </div>
            <button
              onClick={startQuiz}
              className="w-full h-14 rounded-[18px] border-[3px] border-[#1A1A2E]/85 font-bold text-base bg-yellow-300 text-[#1A1A2E] mb-3"
              style={{ boxShadow: '0 6px 0 rgba(26, 26, 46, 0.85)' }}
            >
              Try Again
            </button>
            <button
              onClick={() => setCurrentScreen('home')}
              className="w-full h-14 rounded-[18px] border-[3px] border-[#1A1A2E]/85 font-bold text-base bg-green-200 text-[#1A1A2E]"
              style={{ boxShadow: '0 6px 0 rgba(26, 26, 46, 0.85)' }}
            >
              Back to Home
            </button>
          </motion.div>
        </motion.div>
      );
    }
    
    const currentQuestion = quizQuestions[currentQuizIndex];
    const options = useMemo(() => {
      const wrongAnswers = wordDatabase
        .filter(w => w.id !== currentQuestion.id)
        .sort(() => Math.random() - 0.5)
        .slice(0, 2)
        .map(w => w.translations[baseLanguage === 'en' ? 'zh' : 'en']);
      return [...wrongAnswers, currentQuestion.translations[baseLanguage === 'en' ? 'zh' : 'en']].sort(() => Math.random() - 0.5);
    }, [currentQuestion, baseLanguage]);
    
    return (
      <motion.div 
        className="min-h-screen bg-red-500 pb-24"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <div className="px-4 py-6 safe-area-top">
          <div className="flex justify-between items-center mb-4">
            <button
              onClick={() => setCurrentScreen('home')}
              className="w-10 h-10 bg-white rounded-full border-[3px] border-[#1A1A2E]/85 flex items-center justify-center"
              style={{ boxShadow: '0 4px 0 rgba(26, 26, 46, 0.85)' }}
            >
              <X className="w-5 h-5 text-[#1A1A2E]" />
            </button>
          </div>
          
          <div className="bg-white rounded-full h-3 overflow-hidden border-[2px] border-[#1A1A2E]/85">
            <motion.div 
              className="h-full bg-yellow-300"
              initial={{ width: 0 }}
              animate={{ width: `${((currentQuizIndex + 1) / quizQuestions.length) * 100}%` }}
            />
          </div>
        </div>
        
        <div className="px-4">
          <motion.div 
            className="bg-white rounded-[22px] border-[3px] border-[#1A1A2E]/85 p-6 mb-6"
            style={{ boxShadow: '0 10px 0 rgba(26, 26, 46, 0.85)' }}
            key={currentQuestion.id}
            {...popIn}
          >
            <p className="text-gray-500 text-sm mb-4">How do you say this in {languageNames[baseLanguage === 'en' ? 'zh' : 'en'][baseLanguage]}?</p>
            <p className="text-2xl font-black text-[#1A1A2E]">{currentQuestion.translations[baseLanguage]}</p>
          </motion.div>
          
          <div className="space-y-3">
            {options.map((option, index) => (
              <motion.button
                key={option}
                className="w-full bg-green-200 rounded-[18px] border-[3px] border-[#1A1A2E]/85 p-4 text-left font-bold text-[#1A1A2E]"
                style={{ boxShadow: '0 6px 0 rgba(26, 26, 46, 0.85)' }}
                {...slideInUp}
                transition={{ delay: index * 0.08 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => handleQuizAnswer(option, currentQuestion.translations[baseLanguage === 'en' ? 'zh' : 'en'])}
              >
                {option}
              </motion.button>
            ))}
          </div>
        </div>
      </motion.div>
    );
  };

  // Conversation Screen
  const ConversationScreen = () => {
    const [refreshKey, setRefreshKey] = useState(0);
    const progress = getCompletionProgress();
    
    // Force refresh when screen is shown
    useEffect(() => {
      setRefreshKey(Date.now());
    }, []);
    
    // Use refreshKey to force re-check completion status
    const checkCompleted = (id: string) => {
      void refreshKey; // Use the variable to avoid unused warning
      return isConversationCompleted(id);
    };
    
    return (
      <motion.div 
        className="min-h-screen bg-red-500 pb-24"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <div className="px-4 py-6 safe-area-top">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-white font-black text-2xl">Conversation Book</h2>
            <div className="bg-white rounded-full px-3 py-1 border-[2px] border-[#1A1A2E]/85">
              <span className="text-sm font-bold text-[#1A1A2E]">{progress.completed}/{progress.total}</span>
            </div>
          </div>
          <p className="text-white/80 text-sm mb-6">{progress.percentage}% completed</p>
          
          {/* Progress bar */}
          <div className="bg-white/30 rounded-full h-3 mb-6 overflow-hidden">
            <motion.div 
              className="bg-yellow-300 h-full rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${progress.percentage}%` }}
              transition={{ duration: 0.5 }}
            />
          </div>
          
          <div className="space-y-4">
            {conversationScenarios.map((scenario, index) => {
              const isCompleted = checkCompleted(scenario.id);
              return (
                <motion.div
                  key={scenario.id}
                  className={`bg-white rounded-[22px] border-[3px] p-4 cursor-pointer ${isCompleted ? 'border-green-500' : 'border-[#1A1A2E]/85'}`}
                  style={{ boxShadow: `0 10px 0 ${isCompleted ? 'rgba(34, 197, 94, 0.5)' : 'rgba(26, 26, 46, 0.85)'}` }}
                  {...slideInUp}
                  transition={{ delay: index * 0.06 }}
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.99 }}
                  onClick={() => {
                    setSelectedConversation(scenario);
                    setCurrentScreen('conversationDetail');
                  }}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="font-bold text-[#1A1A2E] text-lg mb-1">{scenario.title[baseLanguage]}</h3>
                      <p className="text-gray-500 text-sm mb-3">{scenario.description[baseLanguage]}</p>
                    </div>
                    {isCompleted && (
                      <div className="bg-green-500 rounded-full p-1 ml-2">
                        <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                    )}
                  </div>
                  <div className="bg-green-200 rounded-[14px] p-3 border-[2px] border-[#1A1A2E]/85">
                    {scenario.dialogues.slice(0, 2).map((dialogue, i) => (
                      <div key={dialogue.id} className={`flex gap-2 ${i > 0 ? 'mt-2' : ''}`}>
                        <span className="font-bold text-xs text-[#1A1A2E] whitespace-nowrap">
                          {dialogue.speaker}:
                        </span>
                        <p className="text-sm text-[#1A1A2E]">{dialogue.text[baseLanguage]}</p>
                      </div>
                    ))}
                    {scenario.dialogues.length > 2 && (
                      <p className="text-gray-500 text-xs mt-2 text-center">+ {scenario.dialogues.length - 2} more</p>
                    )}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </motion.div>
    );
  };

  // Conversation Detail Screen
  const ConversationDetailScreen = () => {
    if (!selectedConversation) return null;
    
    const [isCompleted, setIsCompleted] = useState(() => isConversationCompleted(selectedConversation.id));
    
    const handleMarkComplete = () => {
      markConversationCompleted(selectedConversation.id);
      setIsCompleted(true);
    };
    
    return (
      <motion.div 
        className="min-h-screen bg-red-500 pb-24"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <div className="sticky top-0 z-20 bg-red-500 safe-area-top px-4 py-4 flex items-center gap-3">
          <motion.button
            onClick={() => setCurrentScreen('conversation')}
            className="w-10 h-10 bg-white rounded-full border-[3px] border-[#1A1A2E]/85 flex items-center justify-center"
            style={{ boxShadow: '0 4px 0 rgba(26, 26, 46, 0.85)' }}
            whileTap={{ scale: 0.95 }}
          >
            <ChevronLeft className="w-5 h-5 text-[#1A1A2E]" />
          </motion.button>
          <h2 className="text-white font-bold text-lg flex-1">{selectedConversation.title[baseLanguage]}</h2>
          {isCompleted && (
            <div className="bg-green-500 rounded-full p-2 border-[2px] border-white">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
              </svg>
            </div>
          )}
        </div>
        
        <div className="px-4 space-y-4">
          {/* Introduction */}
          <motion.div 
            className="bg-yellow-100 rounded-[22px] border-[3px] border-[#1A1A2E]/85 p-4"
            style={{ boxShadow: '0 10px 0 rgba(26, 26, 46, 0.85)' }}
            {...popIn}
          >
            <p className="text-gray-600 text-sm">{selectedConversation.introduction[baseLanguage]}</p>
          </motion.div>
          
          {/* Useful Words */}
          <motion.div 
            className="bg-white rounded-[22px] border-[3px] border-[#1A1A2E]/85 p-4"
            style={{ boxShadow: '0 10px 0 rgba(26, 26, 46, 0.85)' }}
            {...slideInUp}
            transition={{ delay: 0.1 }}
          >
            <p className="text-gray-500 text-xs font-bold uppercase tracking-wider mb-3">Useful Words</p>
            <div className="grid grid-cols-2 gap-2">
              {selectedConversation.usefulWords.map((word, i) => (
                <div key={i} className="bg-green-100 rounded-[10px] p-2 border-[2px] border-[#1A1A2E]/50">
                  <p className="text-xs text-gray-500">{word[baseLanguage]}</p>
                  <p className="text-sm font-bold text-[#1A1A2E]">{word.zh}</p>
                </div>
              ))}
            </div>
          </motion.div>
          
          {/* Dialogues */}
          <motion.div 
            className="space-y-3"
            {...slideInUp}
            transition={{ delay: 0.2 }}
          >
            <p className="text-white font-bold text-sm">Conversation ({selectedConversation.dialogues.length} sentences)</p>
            {selectedConversation.dialogues.map((dialogue, index) => (
              <motion.div
                key={dialogue.id}
                className="bg-white rounded-[18px] border-[3px] border-[#1A1A2E]/85 p-4"
                style={{ boxShadow: '0 6px 0 rgba(26, 26, 46, 0.85)' }}
                {...slideInUp}
                transition={{ delay: 0.3 + index * 0.05 }}
              >
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xs font-bold text-red-500 bg-red-100 px-2 py-0.5 rounded-full">{dialogue.speaker}</span>
                  <span className="text-xs text-gray-400">#{index + 1}</span>
                </div>
                <p className="text-[#1A1A2E] font-medium">{dialogue.text[baseLanguage]}</p>
                <p className="text-gray-500 text-sm mt-1">{dialogue.text.zh}</p>
                <button
                  onClick={() => speakText(dialogue.text[baseLanguage], baseLanguage)}
                  className="flex items-center gap-1 mt-2 px-2 py-1 bg-blue-100 rounded-full text-xs font-semibold"
                >
                  <Volume2 className="w-3 h-3" />
                  Listen
                </button>
              </motion.div>
            ))}
          </motion.div>
          
          {/* Mark Complete Button */}
          <motion.div 
            className="pt-4 pb-8"
            {...slideInUp}
            transition={{ delay: 0.5 }}
          >
            {isCompleted ? (
              <div className="bg-green-500 rounded-[22px] border-[3px] border-[#1A1A2E]/85 p-4 text-center"
                style={{ boxShadow: '0 10px 0 rgba(34, 197, 94, 0.5)' }}
              >
                <div className="flex items-center justify-center gap-2">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-white font-bold text-lg">Completed!</span>
                </div>
                <p className="text-white/80 text-sm mt-1">Great job finishing this conversation!</p>
              </div>
            ) : (
              <motion.button
                onClick={handleMarkComplete}
                className="w-full bg-yellow-300 rounded-[22px] border-[3px] border-[#1A1A2E]/85 p-4 text-center"
                style={{ boxShadow: '0 10px 0 rgba(26, 26, 46, 0.85)' }}
                whileTap={{ scale: 0.98 }}
              >
                <span className="text-[#1A1A2E] font-bold text-lg">Mark as Complete</span>
                <p className="text-[#1A1A2E]/70 text-sm mt-1">Tap when you finish reading</p>
              </motion.button>
            )}
          </motion.div>
        </div>
      </motion.div>
    );
  };

  // Settings Screen
  const SettingsScreen = () => (
    <motion.div 
      className="min-h-screen bg-red-500 pb-24"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <div className="px-4 py-6 safe-area-top">
        <h2 className="text-white font-black text-2xl mb-6">Settings</h2>
        
        <div className="space-y-4">
          <motion.div 
            className="bg-white rounded-[22px] border-[3px] border-[#1A1A2E]/85 p-4"
            style={{ boxShadow: '0 10px 0 rgba(26, 26, 46, 0.85)' }}
            {...slideInUp}
          >
            <p className="text-gray-500 text-xs font-bold uppercase tracking-wider mb-3">Base Language</p>
            <div className="flex gap-2">
              {(['en', 'zh', 'uz'] as Language[]).map((lang) => (
                <button
                  key={lang}
                  onClick={() => setBaseLanguage(lang)}
                  className={`flex-1 py-3 rounded-[14px] border-[3px] border-[#1A1A2E]/85 font-bold text-sm transition-all ${
                    baseLanguage === lang ? 'bg-yellow-300' : 'bg-gray-100'
                  }`}
                  style={{ boxShadow: baseLanguage === lang ? '0 4px 0 rgba(26, 26, 46, 0.85)' : 'none' }}
                >
                  {lang === 'en' ? 'English' : lang === 'zh' ? '中文' : 'O\'zbek'}
                </button>
              ))}
            </div>
          </motion.div>
          
          <motion.div 
            className="bg-white rounded-[22px] border-[3px] border-[#1A1A2E]/85 p-4"
            style={{ boxShadow: '0 10px 0 rgba(26, 26, 46, 0.85)' }}
            {...slideInUp}
            transition={{ delay: 0.1 }}
          >
            <p className="text-gray-500 text-xs font-bold uppercase tracking-wider mb-3">Database Stats</p>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-green-200 rounded-[14px] p-3 border-[2px] border-[#1A1A2E]/85 text-center">
                <p className="text-2xl font-black text-[#1A1A2E]">{databaseStats.totalWords.toLocaleString()}</p>
                <p className="text-xs text-gray-500">Total Words</p>
              </div>
              <div className="bg-blue-200 rounded-[14px] p-3 border-[2px] border-[#1A1A2E]/85 text-center">
                <p className="text-2xl font-black text-[#1A1A2E]">{Object.keys(databaseStats.categories).length}</p>
                <p className="text-xs text-gray-500">Categories</p>
              </div>
              <div className="bg-pink-200 rounded-[14px] p-3 border-[2px] border-[#1A1A2E]/85 text-center">
                <p className="text-2xl font-black text-[#1A1A2E]">{favorites.length}</p>
                <p className="text-xs text-gray-500">Your Favorites</p>
              </div>
              <div className="bg-yellow-200 rounded-[14px] p-3 border-[2px] border-[#1A1A2E]/85 text-center">
                <p className="text-2xl font-black text-[#1A1A2E]">{conversationScenarios.length}</p>
                <p className="text-xs text-gray-500">Conversations</p>
              </div>
            </div>
          </motion.div>
          
          <motion.div 
            className="bg-white rounded-[22px] border-[3px] border-[#1A1A2E]/85 p-4"
            style={{ boxShadow: '0 10px 0 rgba(26, 26, 46, 0.85)' }}
            {...slideInUp}
            transition={{ delay: 0.2 }}
          >
            <p className="text-gray-500 text-xs font-bold uppercase tracking-wider mb-3">About</p>
            <div className="space-y-2">
              <div className="flex justify-between items-center py-2">
                <span className="text-[#1A1A2E] font-medium">Version</span>
                <span className="text-gray-500 text-sm">1.0.0</span>
              </div>
              <div className="flex justify-between items-center py-2">
                <span className="text-[#1A1A2E] font-medium">Made by</span>
                <span className="text-red-500 font-bold text-sm">MikkyExpert</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );

  // Bottom Navigation
  const BottomNav = () => {
    const navItems = [
      { id: 'home', icon: Home, label: 'Home' },
      { id: 'favorites', icon: Heart, label: 'Favorites' },
      { id: 'conversation', icon: BookOpen, label: 'Book' },
      { id: 'quiz', icon: MessageCircle, label: 'Quiz' },
      { id: 'settings', icon: Settings, label: 'Settings' },
    ];
    
    const activeScreen = currentScreen === 'detail' || currentScreen === 'conversationDetail' ? 'home' : currentScreen;
    
    return (
      <div className="fixed bottom-0 left-0 right-0 h-[72px] bg-white border-t-[3px] border-[#1A1A2E]/85 flex justify-around items-center px-2 safe-area-bottom">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeScreen === item.id;
          return (
            <motion.button
              key={item.id}
              onClick={() => setCurrentScreen(item.id as typeof currentScreen)}
              className={`flex flex-col items-center justify-center py-2 px-4 rounded-[14px] transition-colors ${
                isActive ? 'bg-yellow-300' : ''
              }`}
              whileTap={{ scale: 0.95 }}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'text-[#1A1A2E]' : 'text-gray-400'}`} />
              <span className={`text-xs mt-1 font-semibold ${isActive ? 'text-[#1A1A2E]' : 'text-gray-400'}`}>
                {item.label}
              </span>
            </motion.button>
          );
        })}
      </div>
    );
  };

  return (
    <div className="relative">
      <AnimatePresence mode="wait">
        {currentScreen === 'onboarding' && <OnboardingScreen key="onboarding" />}
        {currentScreen === 'home' && <HomeScreen key="home" />}
        {currentScreen === 'detail' && <DetailScreen key="detail" />}
        {currentScreen === 'favorites' && <FavoritesScreen key="favorites" />}
        {currentScreen === 'quiz' && <QuizScreen key="quiz" />}
        {currentScreen === 'conversation' && <ConversationScreen key="conversation" />}
        {currentScreen === 'conversationDetail' && <ConversationDetailScreen key="conversationDetail" />}
        {currentScreen === 'settings' && <SettingsScreen key="settings" />}
      </AnimatePresence>
      
      {currentScreen !== 'onboarding' && <BottomNav />}
    </div>
  );
}

export default App;
